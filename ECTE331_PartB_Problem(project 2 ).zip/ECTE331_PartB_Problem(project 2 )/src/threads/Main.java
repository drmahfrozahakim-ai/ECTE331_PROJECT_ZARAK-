package threads;

import java.util.concurrent.atomic.AtomicInteger;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        // run a lot of times so we actually catch a race condition if one exists
        int iterations = 100_000;

        SharedData data = new SharedData();
        SyncSignals sync = new SyncSignals();
        AtomicInteger mismatches = new AtomicInteger(0); // counts how many times the values came out wrong

        Thread threadA = new Thread(new ThreadA(data, sync, iterations, mismatches), "ThreadA");
        Thread threadB = new Thread(new ThreadB(data, sync, iterations), "ThreadB");

        long start = System.currentTimeMillis();
        threadA.start();
        threadB.start();

        // wait for both threads to finish before printing results
        threadA.join();
        threadB.join();
        long end = System.currentTimeMillis();

        System.out.println("Iterations run   : " + iterations);
        System.out.println("Mismatches found : " + mismatches.get());
        System.out.println("Final values     : A1=" + data.A1 + " B1=" + data.B1
                + " B2=" + data.B2 + " A2=" + data.A2 + " B3=" + data.B3 + " A3=" + data.A3);
        System.out.println("Time taken (ms)  : " + (end - start));

        // if mismatches is still 0 after 100k runs, the sync logic is solid
        if (mismatches.get() == 0) {
            System.out.println("RESULT: PASS - synchronisation held for every iteration.");
        } else {
            System.out.println("RESULT: FAIL - a dependency was violated at least once.");
        }
    }
}