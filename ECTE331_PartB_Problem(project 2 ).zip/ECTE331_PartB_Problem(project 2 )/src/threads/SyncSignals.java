package threads;
 
import java.util.concurrent.Semaphore;
 
/**
 * One semaphore per cross-thread dependency edge in Figure 2.1.
 * Each starts with 0 permits: a permit only appears once the value
 * it represents has actually been produced, so the consumer side
 * blocks (without spinning or sleeping) until it's ready.
 */
public class SyncSignals {
 
    public final Semaphore a1Ready = new Semaphore(0); // FuncA1 -> FuncB2
    public final Semaphore b2Ready = new Semaphore(0); // FuncB2 -> FuncA2
    public final Semaphore a2Ready = new Semaphore(0); // FuncA2 -> FuncB3
    public final Semaphore b3Ready = new Semaphore(0); // FuncB3 -> FuncA3
}
 