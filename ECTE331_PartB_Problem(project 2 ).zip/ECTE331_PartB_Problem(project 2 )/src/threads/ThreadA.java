package threads;
 
import java.util.concurrent.atomic.AtomicInteger;
 
/**
 * Runs FuncA1 -> (wait for B2) -> FuncA2 -> (wait for B3) -> FuncA3,
 * repeated for a given number of iterations, checking correctness
 * of its own results each time.
 */
public class ThreadA implements Runnable {
 
    private final SharedData data;
    private final SyncSignals sync;
    private final int iterations;
    private final AtomicInteger mismatches;
 
    public ThreadA(SharedData data, SyncSignals sync, int iterations, AtomicInteger mismatches) {
        this.data = data;
        this.sync = sync;
        this.iterations = iterations;
        this.mismatches = mismatches;
    }
 
    @Override
    public void run() {
        for (int iter = 0; iter < iterations; iter++) {
 
            // FuncA1 - no dependency
            data.A1 = SumUtility.sumUpTo(500);
            sync.a1Ready.release(); // tell FuncB2 that A1 is ready
 
            // FuncA2 - needs B2
            try {
                sync.b2Ready.acquire();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            data.A2 = data.B2 + SumUtility.sumUpTo(300);
            sync.a2Ready.release(); // tell FuncB3 that A2 is ready
 
            // FuncA3 - needs B3
            try {
                sync.b3Ready.acquire();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            data.A3 = data.B3 + SumUtility.sumUpTo(400);
 
            // sanity check against the expected constants from Part a)
            if (data.A1 != 125_250 || data.A2 != 190_500 || data.A3 != 350_900) {
                mismatches.incrementAndGet();
            }
        }
    }
}