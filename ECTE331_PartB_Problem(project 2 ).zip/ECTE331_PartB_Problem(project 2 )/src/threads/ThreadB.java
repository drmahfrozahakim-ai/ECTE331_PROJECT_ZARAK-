package threads;
 
/**
 * Runs FuncB1 -> (wait for A1) -> FuncB2 -> (wait for A2) -> FuncB3,
 * repeated for a given number of iterations.
 */
public class ThreadB implements Runnable {
 
    private final SharedData data;
    private final SyncSignals sync;
    private final int iterations;
 
    public ThreadB(SharedData data, SyncSignals sync, int iterations) {
        this.data = data;
        this.sync = sync;
        this.iterations = iterations;
    }
 
    @Override
    public void run() {
        for (int iter = 0; iter < iterations; iter++) {
 
            // FuncB1 - no dependency
            data.B1 = SumUtility.sumUpTo(250);
 
            // FuncB2 - needs A1
            try {
                sync.a1Ready.acquire();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            data.B2 = data.A1 + SumUtility.sumUpTo(200);
            sync.b2Ready.release(); // tell FuncA2 that B2 is ready
 
            // FuncB3 - needs A2
            try {
                sync.a2Ready.acquire();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            data.B3 = data.A2 + SumUtility.sumUpTo(400);
            sync.b3Ready.release(); // tell FuncA3 that B3 is ready
        }
    }
}