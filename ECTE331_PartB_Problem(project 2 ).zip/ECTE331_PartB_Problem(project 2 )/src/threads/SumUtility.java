package threads;
 
/**
 * Dedicated utility class for computing sum(0..n).
 * Uses a loop on purpose (as required by the assignment), even though
 * a closed-form formula exists - this is just to keep the "work" done
 * inside the thread functions realistic.
 */
public class SumUtility {
 
    public static long sumUpTo(int n) {
        long sum = 0;
        for (int i = 0; i <= n; i++) {
            sum += i;
        }
        return sum;
    }
}