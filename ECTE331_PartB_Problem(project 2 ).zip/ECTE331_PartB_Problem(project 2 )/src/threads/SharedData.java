package threads;

/**
 * Holds the six shared integer variables both threads read/write.
 * volatile is used so that once a semaphore permit is acquired,
 * the reading thread is guaranteed to see the latest write.
 */
public class SharedData {

    public volatile long A1;
    public volatile long A2;
    public volatile long A3;
    public volatile long B1;
    public volatile long B2;
    public volatile long B3;
}