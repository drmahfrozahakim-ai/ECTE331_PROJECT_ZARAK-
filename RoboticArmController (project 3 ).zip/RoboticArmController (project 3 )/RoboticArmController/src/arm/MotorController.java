package arm;

/**
 * Simulates control of the robotic arm motor. This is the single shared
 * resource that all three real-time threads must access exclusively.
 *
 * <p>Mutual exclusion is implemented with a classic monitor pattern
 * (a {@code synchronized} method plus a boolean flag and
 * {@code wait()}/{@code notifyAll()}), rather than {@code java.util.concurrent}
 * locks, to stay within core Java primitives supported by any
 * Java-compliant VM, including JamaicaVM.</p>
 *
 * <p>Depending on the configured {@link SchedulingMode}, this class also
 * applies priority inheritance or priority ceiling to prevent (or
 * demonstrate) priority inversion.</p>
 */
public class MotorController {

    private static final int CEILING_PRIORITY = Thread.MAX_PRIORITY;

    private boolean locked = false;
    private Thread currentHolder = null;

    private volatile SchedulingMode mode = SchedulingMode.NONE;

    // bookkeeping for restoring priorities once the resource is released
    private int savedCeilingPriority = -1;
    private int holderOriginalPriority = -1;
    private boolean holderBoosted = false;

    public void setMode(SchedulingMode mode) {
        this.mode = mode;
    }

    public SchedulingMode getMode() {
        return mode;
    }

    /**
     * Blocks until the calling thread has exclusive access to the motor.
     * If priority inheritance is enabled and the resource is already held
     * by a lower-priority thread, that thread's priority is temporarily
     * boosted to the caller's priority.
     *
     * @param taskLabel a short label used in log output, e.g. "SafetyMonitor"
     * @return the number of nanoseconds this thread spent waiting
     * @throws InterruptedException if the thread is interrupted while waiting
     */
    public synchronized long acquire(String taskLabel) throws InterruptedException {

        long start = System.nanoTime();
        int callerPriority = Thread.currentThread().getPriority();

        // priority inheritance: boost the current holder if it is blocking someone
        // of higher priority
        if (mode == SchedulingMode.INHERITANCE && locked && currentHolder != null
                && currentHolder.getPriority() < callerPriority) {
            holderOriginalPriority = currentHolder.getPriority();
            holderBoosted = true;
            currentHolder.setPriority(callerPriority);
            SystemLogger.log("PRIORITY INHERITANCE: " + currentHolder.getName()
                    + " boosted from " + holderOriginalPriority + " to " + callerPriority
                    + " because " + taskLabel + " is waiting");
        }

        while (locked) {
            wait();
        }

        locked = true;
        currentHolder = Thread.currentThread();

        long waited = System.nanoTime() - start;

        if (mode == SchedulingMode.CEILING) {
            savedCeilingPriority = Thread.currentThread().getPriority();
            Thread.currentThread().setPriority(CEILING_PRIORITY);
            SystemLogger.log(taskLabel + " acquired MotorController - CEILING priority "
                    + CEILING_PRIORITY + " applied");
        } else {
            SystemLogger.log(taskLabel + " acquired MotorController");
        }

        return waited;
    }

    /**
     * Releases the motor, restoring any temporarily boosted priority and
     * waking up the next waiting thread.
     *
     * @param taskLabel a short label used in log output
     */
    public synchronized void release(String taskLabel) {

        if (mode == SchedulingMode.CEILING) {
            Thread.currentThread().setPriority(savedCeilingPriority);
            SystemLogger.log(taskLabel + " released MotorController - priority restored to "
                    + savedCeilingPriority);

        } else if (mode == SchedulingMode.INHERITANCE && holderBoosted
                && Thread.currentThread() == currentHolder) {
            Thread.currentThread().setPriority(holderOriginalPriority);
            SystemLogger.log("PRIORITY INHERITANCE: " + taskLabel + " priority restored to "
                    + holderOriginalPriority);
            holderBoosted = false;

        } else {
            SystemLogger.log(taskLabel + " released MotorController");
        }

        locked = false;
        currentHolder = null;
        notifyAll();
    }
}