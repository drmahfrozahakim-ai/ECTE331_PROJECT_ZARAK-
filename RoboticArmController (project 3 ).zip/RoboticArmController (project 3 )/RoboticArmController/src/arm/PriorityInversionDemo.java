package arm;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Runs a single controlled scenario reproducing the classic priority
 * inversion setup described in Task 3:
 * <ol>
 *     <li>the Low-priority thread acquires the shared resource first</li>
 *     <li>shortly after, the High-priority thread tries to acquire it and blocks</li>
 *     <li>meanwhile the Medium-priority thread runs unrelated CPU-bound work,
 *         competing for CPU time and extending how long Low takes to finish
 *         (and therefore how long High is blocked) - unless Low has been
 *         protected by priority inheritance or priority ceiling</li>
 * </ol>
 *
 * <p>The same scenario is reused for Tasks 3, 4, 5 and 6 simply by changing
 * the {@link SchedulingMode} passed to {@link #runScenario}, which makes the
 * three cases directly comparable.</p>
 */
public class PriorityInversionDemo {

    /** Holds the measured results of one scenario run. */
    public static class Result {
        public final double waitTimeMs;
        public final double responseTimeMs;

        public Result(double waitTimeMs, double responseTimeMs) {
            this.waitTimeMs = waitTimeMs;
            this.responseTimeMs = responseTimeMs;
        }
    }

    public static Result runScenario(MotorController controller, SchedulingMode mode) throws InterruptedException {

        controller.setMode(mode);

        AtomicBoolean mediumActive = new AtomicBoolean(false);
        long[] waitNanos = new long[1];
        long[] responseNanos = new long[1];

        // LOW priority thread - grabs the resource first and holds it while "working"
        Thread lowThread = new Thread(() -> {
            try {
                SystemLogger.log("Logger attempting to acquire MotorController");
                controller.acquire("Logger");
                SystemLogger.log("Logger is now holding MotorController");

                // simulate a multi-step logging operation. If the Motion Planner is
                // active AND we have not been protected (inheritance/ceiling), each
                // step is delayed - this reproduces the priority-inversion effect
                // in a controlled, repeatable way.
                for (int step = 0; step < 5; step++) {
                    Thread.sleep(100);
                    if (mediumActive.get() && Thread.currentThread().getPriority() < MotionPlannerTask.PRIORITY) {
                        SystemLogger.log("Logger delayed by Motion Planner activity (unprotected)");
                        Thread.sleep(150);
                    }
                }

                controller.release("Logger");
                SystemLogger.log("Logger released MotorController");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Logger-Thread");
        lowThread.setPriority(ActivityLoggerTask.PRIORITY);

        // MEDIUM priority thread - unrelated CPU-bound work, competing for CPU time
        Thread mediumThread = new Thread(() -> {
            try {
                Thread.sleep(150); // let Low grab the resource first
                mediumActive.set(true);
                SystemLogger.log("Motion Planner running (not touching the resource)");

                long endAt = System.currentTimeMillis() + 700;
                while (System.currentTimeMillis() < endAt) {
                    Math.sqrt(12345.6789); // trivial CPU-bound busy work
                }

                mediumActive.set(false);
                SystemLogger.log("Motion Planner finished its work");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "MotionPlanner-Thread");
        mediumThread.setPriority(MotionPlannerTask.PRIORITY);

        // HIGH priority thread - tries to access the resource shortly after Low grabs it
        Thread highThread = new Thread(() -> {
            try {
                Thread.sleep(50); // let Low grab the resource first

                SystemLogger.log("Safety Monitor attempting to acquire MotorController");
                long responseStart = System.nanoTime();

                long waited = controller.acquire("SafetyMonitor");
                waitNanos[0] = waited;
                SystemLogger.log(String.format("Safety Monitor ACQUIRED MotorController after waiting %.2f ms",
                        waited / 1_000_000.0));

                Thread.sleep(50); // simulated emergency-stop action

                controller.release("SafetyMonitor");
                responseNanos[0] = System.nanoTime() - responseStart;
                SystemLogger.log("Safety Monitor completed emergency stop and released MotorController");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "SafetyMonitor-Thread");
        highThread.setPriority(SafetyMonitorTask.PRIORITY);

        lowThread.start();
        mediumThread.start();
        highThread.start();

        lowThread.join();
        mediumThread.join();
        highThread.join();

        double waitMs = waitNanos[0] / 1_000_000.0;
        double responseMs = responseNanos[0] / 1_000_000.0;

        SystemLogger.log(String.format("SCENARIO RESULT (%s): waitTime=%.2fms, responseTime=%.2fms",
                mode, waitMs, responseMs));

        return new Result(waitMs, responseMs);
    }
}