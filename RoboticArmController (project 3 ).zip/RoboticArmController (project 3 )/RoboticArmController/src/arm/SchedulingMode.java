package arm;

/**
 * The scheduling / priority-management policy currently applied by
 * {@link MotorController} when its critical section is accessed.
 */
public enum SchedulingMode {

    /** No priority management - the baseline case used to demonstrate priority inversion. */
    NONE,

    /** Priority inheritance - a blocked high-priority thread temporarily boosts the holder. */
    INHERITANCE,

    /** Priority ceiling - any thread holding the resource runs at a fixed ceiling priority. */
    CEILING
}