package arm;

import java.util.Random;

/**
 * Medium-priority real-time task. Periodically sends movement commands
 * to the motor controller.
 */
public class MotionPlannerTask implements Runnable {

    public static final int PRIORITY = Thread.NORM_PRIORITY;

    private final MotorController controller;
    private final int cycles;

    public MotionPlannerTask(MotorController controller, int cycles) {
        this.controller = controller;
        this.cycles = cycles;
    }

    @Override
    public void run() {
        Random random = new Random();

        for (int cycle = 1; cycle <= cycles; cycle++) {
            try {
                Thread.sleep(200 + random.nextInt(150)); // time between movement commands

                SystemLogger.log("Motion Planner requesting access to send movement command (cycle " + cycle + ")");
                controller.acquire("MotionPlanner");

                SystemLogger.log("Motion Planner sending movement command (cycle " + cycle + ")");
                Thread.sleep(150); // simulated command execution time

                controller.release("MotionPlanner");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}