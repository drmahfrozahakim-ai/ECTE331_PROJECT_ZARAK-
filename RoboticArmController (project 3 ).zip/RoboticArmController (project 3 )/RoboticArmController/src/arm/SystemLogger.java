package arm;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Small utility for timestamped console logging and CSV export of
 * performance results. All methods are synchronized so multiple
 * real-time threads can log concurrently without interleaving output.
 */
public class SystemLogger {

    private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss.SSS");
    private static PrintWriter csvWriter;

    private SystemLogger() {
        // utility class - no instances
    }

    /** Prints a timestamped line to the console. */
    public static synchronized void log(String message) {
        System.out.println("[" + TIME_FORMAT.format(new Date()) + "] "
                + Thread.currentThread().getName() + " : " + message);
    }

    /** Opens a CSV file and writes the header row, ready for {@link #logCsv}. */
    public static synchronized void initCsv(String fileName) throws IOException {
        csvWriter = new PrintWriter(new FileWriter(fileName, false));
        csvWriter.println("Mode,Run,WaitTimeMs,ResponseTimeMs");
        csvWriter.flush();
    }

    /** Appends one performance measurement row to the CSV file. */
    public static synchronized void logCsv(String mode, int run, double waitMs, double responseMs) {
        if (csvWriter != null) {
            csvWriter.println(mode + "," + run + "," + waitMs + "," + responseMs);
            csvWriter.flush();
        }
    }

    /** Closes the CSV file. */
    public static synchronized void closeCsv() {
        if (csvWriter != null) {
            csvWriter.close();
        }
    }
}