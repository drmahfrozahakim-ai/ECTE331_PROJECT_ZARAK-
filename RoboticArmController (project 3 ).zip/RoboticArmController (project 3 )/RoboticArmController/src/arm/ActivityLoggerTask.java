package arm;

import java.util.Random;

/**
 * Low-priority real-time task. Periodically records system activity,
 * which requires briefly accessing the shared motor controller state.
 */
public class ActivityLoggerTask implements Runnable {

    public static final int PRIORITY = Thread.MIN_PRIORITY;

    private final MotorController controller;
    private final int cycles;

    public ActivityLoggerTask(MotorController controller, int cycles) {
        this.controller = controller;
        this.cycles = cycles;
    }

    @Override
    public void run() {
        Random random = new Random();

        for (int cycle = 1; cycle <= cycles; cycle++) {
            try {
                Thread.sleep(150 + random.nextInt(150)); // time between log entries

                SystemLogger.log("Logger requesting access to record activity (cycle " + cycle + ")");
                controller.acquire("Logger");

                SystemLogger.log("Logger recording activity (cycle " + cycle + ")");
                Thread.sleep(200); // simulated logging time

                controller.release("Logger");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}