package arm;

import java.util.Random;

/**
 * High-priority real-time task. Periodically checks for emergency
 * conditions and, if needed, accesses the motor controller to stop the arm.
 */
public class SafetyMonitorTask implements Runnable {

    public static final int PRIORITY = Thread.MAX_PRIORITY;

    private final MotorController controller;
    private final int cycles;

    public SafetyMonitorTask(MotorController controller, int cycles) {
        this.controller = controller;
        this.cycles = cycles;
    }

    @Override
    public void run() {
        Random random = new Random();

        for (int cycle = 1; cycle <= cycles; cycle++) {
            try {
                Thread.sleep(300 + random.nextInt(200)); // time between safety checks

                SystemLogger.log("Safety Monitor checking for emergency conditions (cycle " + cycle + ")");
                controller.acquire("SafetyMonitor");

                SystemLogger.log("Safety Monitor stopping arm motor if required (cycle " + cycle + ")");
                Thread.sleep(50); // simulated stop action

                controller.release("SafetyMonitor");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}