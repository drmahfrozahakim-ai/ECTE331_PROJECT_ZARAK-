package arm;

import java.io.IOException;

/**
 * Entry point. Runs, in order:
 * Task 1/2 (basic multi-threaded access with synchronization),
 * Task 3 (priority inversion, unprotected),
 * Task 4 (priority inheritance),
 * Task 5 (priority ceiling),
 * Task 6 (performance evaluation across all three modes, averaged over
 * multiple runs, exported to CSV for charting).
 */
public class Main {

    private Main() {
        // entry point only - not meant to be instantiated
    }

    public static void main(String[] args) throws Exception {

        System.out.println("=================================================");
        System.out.println(" Real-Time Robotic Arm Controller Simulation");
        System.out.println("=================================================");

        runBasicMultithreadedDemo();

        System.out.println();
        System.out.println("---------- Task 3: Priority Inversion (no protection) ----------");
        PriorityInversionDemo.runScenario(new MotorController(), SchedulingMode.NONE);

        System.out.println();
        System.out.println("---------- Task 4: Priority Inheritance ----------");
        PriorityInversionDemo.runScenario(new MotorController(), SchedulingMode.INHERITANCE);

        System.out.println();
        System.out.println("---------- Task 5: Priority Ceiling ----------");
        PriorityInversionDemo.runScenario(new MotorController(), SchedulingMode.CEILING);

        System.out.println();
        System.out.println("---------- Task 6: Performance Evaluation ----------");
        runPerformanceEvaluation(10);

        System.out.println();
        System.out.println("Simulation complete. See performance_results.csv for full data.");
    }

    /** Tasks 1 & 2: the three real-time threads repeatedly accessing the shared resource. */
    private static void runBasicMultithreadedDemo() throws InterruptedException {
        System.out.println("---------- Task 1 & 2: Basic Multi-threaded Access ----------");

        MotorController controller = new MotorController(); // SchedulingMode.NONE by default

        Thread safety = new Thread(new SafetyMonitorTask(controller, 5), "SafetyMonitor-Thread");
        Thread motion = new Thread(new MotionPlannerTask(controller, 5), "MotionPlanner-Thread");
        Thread logger = new Thread(new ActivityLoggerTask(controller, 5), "Logger-Thread");

        safety.setPriority(SafetyMonitorTask.PRIORITY);
        motion.setPriority(MotionPlannerTask.PRIORITY);
        logger.setPriority(ActivityLoggerTask.PRIORITY);

        safety.start();
        motion.start();
        logger.start();

        safety.join();
        motion.join();
        logger.join();
    }

    /** Task 6: repeats the controlled scenario several times per mode and averages the results. */
    private static void runPerformanceEvaluation(int runsPerMode) throws IOException, InterruptedException {

        SystemLogger.initCsv("performance_results.csv");

        SchedulingMode[] modes = { SchedulingMode.NONE, SchedulingMode.INHERITANCE, SchedulingMode.CEILING };

        for (SchedulingMode mode : modes) {
            double totalWait = 0;
            double totalResponse = 0;

            for (int run = 1; run <= runsPerMode; run++) {
                MotorController controller = new MotorController();
                PriorityInversionDemo.Result result = PriorityInversionDemo.runScenario(controller, mode);

                totalWait += result.waitTimeMs;
                totalResponse += result.responseTimeMs;

                SystemLogger.logCsv(mode.name(), run, result.waitTimeMs, result.responseTimeMs);
                Thread.sleep(200); // brief pause between runs
            }

            double avgWait = totalWait / runsPerMode;
            double avgResponse = totalResponse / runsPerMode;

            System.out.printf("Mode %-11s : avg waitTime=%.2fms, avg responseTime=%.2fms%n",
                    mode, avgWait, avgResponse);
        }

        SystemLogger.closeCsv();
    }
}