/**
 * Module for the ECTE331 fault tolerant drone navigation system.
 * Contains the {@code drone} package with the sensor simulation,
 * TMR voting, logging, and exception-handling classes.
 */
module DroneNavigationSystem {
}
