package drone;

import java.util.Random;

/**
 * Represents one redundant altitude sensor used by the drone's
 * Triple Modular Redundancy (TMR) voting scheme.
 *
 * <p>Each call to {@link #readSensor()} simulates one of three outcomes,
 * chosen by a random "chance" value between 0 and 99 inclusive:</p>
 * <ul>
 *     <li>0-14  : the sensor fails, and a {@link SensorReadException} is thrown</li>
 *     <li>15-29 : the sensor returns a corrupted reading (outside [0,200])</li>
 *     <li>30-99 : the sensor returns a valid reading (within [0,200])</li>
 * </ul>
 */
public class Sensor {

    private final String sensorID;
    private final int baselineValue;
    private final Random random = new Random(); // each sensor gets its own generator

    /**
     * Creates a sensor with a default baseline altitude of 100 metres.
     *
     * @param sensorID a human-readable identifier for this sensor, e.g. "Sensor A"
     */
    public Sensor(String sensorID) {
        this(sensorID, 100);
    }

    /**
     * Creates a sensor with a specified baseline altitude.
     *
     * @param sensorID      a human-readable identifier for this sensor, e.g. "Sensor A"
     * @param baselineValue the altitude (in metres) around which valid readings are centred
     */
    public Sensor(String sensorID, int baselineValue) {
        this.sensorID = sensorID;
        this.baselineValue = baselineValue;
    }

    /**
     * @return this sensor's identifier
     */
    public String getSensorID() {
        return sensorID;
    }

    /**
     * Simulates a single altitude reading.
     *
     * @return the simulated reading (may be corrupted / out of range)
     * @throws SensorReadException if the sensor "fails" this cycle
     */
    public int readSensor() throws SensorReadException {

        int chance = random.nextInt(100); // 0-99 inclusive

        // 15% chance of an outright sensor failure
        if (chance < 15) {
            throw new SensorReadException(sensorID + " failed to produce a reading (chance=" + chance + ").");
        }

        // another 15% chance of a corrupted (out-of-range) reading
        if (chance < 30) {
            // push it outside the valid [0,200] range, either below zero or above two hundred
            if (random.nextBoolean()) {
                return -1 - random.nextInt(50);   // e.g. -1 .. -50
            } else {
                return 201 + random.nextInt(100); // e.g. 201 .. 300
            }
        }

        // remaining 70% chance: valid reading, baseline +/- a small offset
        int reading = baselineValue + random.nextInt(21) - 10; // baseline-10 .. baseline+10

        // just in case the offset pushes it past the valid bounds, clamp it back in
        if (reading < 0) {
            reading = 0;
        } else if (reading > 200) {
            reading = 200;
        }
        return reading;
    }
}
