package drone;

import java.io.IOException;
import java.util.Random;

/**
 * Entry point for the fault-tolerant drone navigation simulation.
 * Runs repeated sensing/voting cycles, logging all significant events
 * to file, until either SAFE MODE is triggered or a cycle cap is reached.
 */
public class Main {

    private Main() {
        // entry point only - not meant to be instantiated
    }

    // the three redundant sensors
    private static final Sensor[] sensors = {
            new Sensor("Sensor A"),
            new Sensor("Sensor B"),
            new Sensor("Sensor C")
    };

    private static int previousAltitude = 100; // fallback value if voting fails
    private static int failureCount = 0;       // consecutive reliability failures

    /**
     * Runs the drone navigation simulation.
     *
     * @param args not used
     */
    public static void main(String[] args) {

        // give each run its own log file so old runs don't get overwritten
        String logFileName = "log_" + new Random().nextInt(100000) + ".txt";

        try {
            LoggerUtility.init(logFileName);
        } catch (IOException e) {
            System.out.println("Could not open log file: " + e.getMessage());
            return;
        }

        System.out.println("======================================");
        System.out.println(" Fault-Tolerant Drone Navigation System");
        System.out.println("======================================");
        System.out.println("Logging to: " + logFileName);

        LoggerUtility.log("Drone Navigation System Started");

        try {
            int cycle = 1;

            while (cycle <= 50) { // safety cap so the demo terminates on its own

                System.out.println("\n--- Cycle " + cycle + " ---");

                int[] values = new int[3];
                boolean[] valid = new boolean[3];
                String[] sensorIDs = new String[3];

                // read every sensor for this cycle
                for (int i = 0; i < sensors.length; i++) {
                    sensorIDs[i] = sensors[i].getSensorID();

                    try {
                        values[i] = sensors[i].readSensor();

                        // even if it didn't throw, the value itself could be corrupted
                        if (values[i] < 0 || values[i] > 200) {
                            valid[i] = false;
                            System.out.println(sensorIDs[i] + " -> CORRUPTED reading: " + values[i]);
                            LoggerUtility.log("CORRUPTED READING: " + sensorIDs[i]
                                    + " produced out-of-range value " + values[i]);
                        } else {
                            valid[i] = true;
                            System.out.println(sensorIDs[i] + " -> " + values[i]);
                        }

                    } catch (SensorReadException e) {
                        // sensor failed outright this cycle
                        valid[i] = false;
                        values[i] = -1;
                        System.out.println(sensorIDs[i] + " -> FAILURE (" + e.getMessage() + ")");
                        LoggerUtility.log("SENSOR FAILURE: " + e.getMessage());
                    }
                }

                // work out what happened this cycle
                boolean majority = VotingSystem.hasMajority(values, valid);
                int altitude = VotingSystem.getMajorityAltitude(values, valid, previousAltitude);
                String outlier = VotingSystem.getOutlierSensor(values, valid, sensorIDs);
                boolean reliabilityFailure = VotingSystem.isReliabilityFailure(valid, majority);

                // just need this for the console/log messages below
                int validCount = 0;
                for (boolean v : valid) {
                    if (v) {
                        validCount++;
                    }
                }

                if (!reliabilityFailure) {

                    // good cycle - reset the failure streak and lock in the new altitude
                    failureCount = 0;
                    previousAltitude = altitude;

                    if (majority) {
                        System.out.println("VOTING DECISION: Majority value = " + altitude);
                        LoggerUtility.log("MAJORITY DECISION: value=" + altitude);

                        if (!outlier.equals("None")) {
                            System.out.println("OUTLIER DETECTED: " + outlier);
                            LoggerUtility.log("OUTLIER DETECTED: " + outlier
                                    + " disagreed with majority value " + altitude);
                        }
                    } else {
                        // all three valid readings disagreed, so just keep the last known altitude
                        System.out.println("VOTING DECISION: All sensors disagree. "
                                + "Falling back to previous altitude = " + altitude);
                        LoggerUtility.log("FALLBACK DECISION: all valid readings differ. "
                                + "Using previous altitude " + altitude);
                    }

                    System.out.println("RELIABILITY STATUS: OK");

                } else {

                    // not enough valid readings, or two readings that don't agree
                    failureCount++;
                    System.out.println("RELIABILITY STATUS: FAILURE (" + validCount
                            + " valid reading(s), consecutive failures = " + failureCount + ")");
                    System.out.println("Falling back to previous altitude: " + previousAltitude);

                    LoggerUtility.log("RELIABILITY FAILURE #" + failureCount + ": only "
                            + validCount + " valid reading(s) this cycle.");

                    // two in a row means we can't trust the sensors anymore - bail out
                    if (failureCount >= 2) {
                        throw new SystemReliabilityException("Two consecutive reliability failures.");
                    }
                }

                System.out.println("Current altitude: " + previousAltitude + " m");
                cycle++;
            }

            // only reached if we made it through all 50 cycles cleanly
            System.out.println("\nCompleted 50 cycles without entering SAFE MODE.");
            LoggerUtility.log("Simulation completed 50 cycles without SAFE MODE.");

        } catch (SystemReliabilityException e) {

            // two consecutive failures - shut things down
            System.out.println("\n*** SAFE MODE ACTIVATED ***");
            System.out.println(e.getMessage());
            LoggerUtility.log("SAFE MODE ACTIVATED: " + e.getMessage());

        } finally {
            // always close the log file, even if we crashed out
            LoggerUtility.close();
        }
    }
}
