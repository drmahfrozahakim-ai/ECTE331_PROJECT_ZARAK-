package drone;

import java.io.IOException;

/**
 * Thrown by {@link Sensor#readSensor()} when a sensor fails to
 * produce a reading at all (simulated hardware failure).
 */
public class SensorReadException extends IOException {

    /**
     * Creates a new exception describing why the sensor failed.
     *
     * @param message a description of the failure, including the sensor ID
     */
    public SensorReadException(String message) {
        super(message);
    }
}
