package drone;

/**
 * Implements the Triple Modular Redundancy (TMR) majority-voting
 * and reliability rules used to decide the drone's altitude each cycle.
 */
public class VotingSystem {

    private VotingSystem() {
        // utility class - no instances
    }

    /**
     * Checks whether at least two valid sensor readings agree on the same value.
     *
     * @param values the readings produced by each sensor this cycle
     * @param valid  whether each corresponding reading in {@code values} is valid
     * @return true if at least two valid sensor readings agree on the same value
     */
    public static boolean hasMajority(int[] values, boolean[] valid) {
        for (int i = 0; i < values.length; i++) {
            if (!valid[i]) {
                continue;
            }
            for (int j = i + 1; j < values.length; j++) {
                if (valid[j] && values[i] == values[j]) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Decides the altitude to use for this cycle.
     * If two valid readings agree, that shared value is returned.
     * Otherwise the previous altitude is returned (this covers both the
     * "all readings differ" fallback case and any other non-majority case).
     *
     * @param values           the readings produced by each sensor this cycle
     * @param valid            whether each corresponding reading in {@code values} is valid
     * @param previousAltitude the altitude used in the previous cycle, used as a fallback
     * @return the altitude (in metres) to use for this cycle
     */
    public static int getMajorityAltitude(int[] values, boolean[] valid, int previousAltitude) {
        for (int i = 0; i < values.length; i++) {
            if (!valid[i]) {
                continue;
            }
            for (int j = i + 1; j < values.length; j++) {
                if (valid[j] && values[i] == values[j]) {
                    return values[i];
                }
            }
        }
        return previousAltitude;
    }

    /**
     * Identifies the single sensor that disagreed with the other two,
     * when exactly one outlier exists among three valid readings.
     *
     * @param values    the readings produced by each sensor this cycle
     * @param valid     whether each corresponding reading in {@code values} is valid
     * @param sensorIDs the identifier of each corresponding sensor
     * @return the outlier's sensor ID, or "None" if not applicable
     */
    public static String getOutlierSensor(int[] values, boolean[] valid, String[] sensorIDs) {
        int validCount = 0;
        for (boolean v : valid) {
            if (v) {
                validCount++;
            }
        }

        if (validCount != 3) {
            return "None";
        }

        for (int i = 0; i < values.length; i++) {
            boolean agreesWithSomeone = false;
            for (int j = 0; j < values.length; j++) {
                if (i != j && values[i] == values[j]) {
                    agreesWithSomeone = true;
                    break;
                }
            }
            if (!agreesWithSomeone) {
                return sensorIDs[i];
            }
        }
        return "None";
    }

    /**
     * A reliability failure occurs when fewer than two valid readings exist,
     * or when there is no majority and no usable fallback (i.e. exactly two
     * valid readings that disagree with each other).
     *
     * @param valid    whether each sensor produced a valid reading this cycle
     * @param majority whether at least two valid readings agreed on a value
     * @return true if this cycle counts as a reliability failure
     */
    public static boolean isReliabilityFailure(boolean[] valid, boolean majority) {
        int validCount = 0;
        for (boolean v : valid) {
            if (v) {
                validCount++;
            }
        }

        if (validCount < 2) {
            return true;
        }
        if (majority) {
            return false;
        }
        // no majority: the only acceptable outcome is "all three valid but differing"
        return validCount != 3;
    }
}
