package drone;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Small utility class responsible for writing timestamped log entries
 * to a file. Must be initialised with {@link #init(String)} before
 * {@link #log(String)} is called, and should be closed with
 * {@link #close()} once the application is done.
 */
public class LoggerUtility {

    private static PrintWriter writer;
    private static final SimpleDateFormat TIMESTAMP_FORMAT =
            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private LoggerUtility() {
        // utility class - no instances
    }

    /**
     * Opens the log file ready for writing.
     *
     * @param fileName name of the log file to create/append to
     * @throws IOException if the file cannot be opened
     */
    public static void init(String fileName) throws IOException {
        writer = new PrintWriter(new FileWriter(fileName, true));
    }

    /**
     * Writes a single timestamped entry to the log file.
     *
     * @param message the event description to record
     */
    public static void log(String message) {
        if (writer == null) {
            System.err.println("LoggerUtility.init() was not called - message lost: " + message);
            return;
        }
        writer.println("[" + TIMESTAMP_FORMAT.format(new Date()) + "] " + message);
        writer.flush();
    }

    /** Closes the underlying file handle. */
    public static void close() {
        if (writer != null) {
            writer.close();
        }
    }
}
