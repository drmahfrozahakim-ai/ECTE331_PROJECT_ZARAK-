package drone;

/**
 * Thrown when the drone controller has experienced two consecutive
 * reliability failures and must transition into SAFE MODE.
 */
public class SystemReliabilityException extends Exception {

    /**
     * Creates a new exception describing why SAFE MODE was triggered.
     *
     * @param message a description of the reliability failure
     */
    public SystemReliabilityException(String message) {
        super(message);
    }
}
